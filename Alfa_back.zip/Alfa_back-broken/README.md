-   Comandos básicos:
    1 - composer install
    2 - cp .env.example .env
    3 - php artisan key:generate

-   Configurar o arquivo .env
-   Comandos para o Sanctum
    1 - composer require laravel/sanctum
    2 - php artisan vendor:publish --provider ="Laravel\Sanctum\SanctumServiceProvider"
-   Extensão do QrCode:
    1 - composer require simplesoftwareio/simple-qrcode
